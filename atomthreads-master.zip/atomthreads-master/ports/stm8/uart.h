
#include "atom.h"


/*
 * Perform UART startup initialization.
 */
int	uart_init(uint32_t baudrate);

